/* 
* @Author: Marte
* @Date:   2016-12-14 10:09:33
* @Last Modified by:   Marte
* @Last Modified time: 2016-12-26 11:34:33
*/
// var reg = '/^\?\w+\=\w+\(\&\=\w+\=\w+\)*$/';
Mock.mock('/activity/ticket1', {
	'url'     : 'https://ptest.jinhui365.cn/login/index',
	'message': {
	    'code|1': [0,-3,1,-9993],
	    'message':'@csentence'
	}
});