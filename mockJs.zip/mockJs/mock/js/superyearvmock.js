 $(document).ready(function(){
        var Request = getRequest();
        var fid = (Request['friendId']);
        var ut = (Request['ut']);
        var client = (Request['client']);
        fid = fid ? fid : '';
        ut = ut ? ut : '';
        client = client ? client : '';
        var oMaskDiv=document.getElementById("mask-invite");
        $("#close").click(function(){
            $("#mask-invite").css('display','none');
            $(".inviteconall .tip").html("");
        });
        var timestamp=new Date().getTime();
        $("#invite-bn").click(function(){
            var mobile = document.getElementById('mobile');
            var timestamp=new Date().getTime();
            var _this=$(this);
            var urlCode = '/activity/ticket1';
            var param ={
                type:2,
                mobile:mobile.value,
                friendId:fid,
                ut:ut,
                client:client
            };
            // if($(this).is(".invitePC")){
                function succ(data){
                    console.log(data.message.code);
                    if(data.message.code == -3){
                        window.location.href=data.url;
                    }else if(data.message.code ==0 ){
                        var msgCont = '<div class="m-cont-msg">\
                                <div class="m-cont-limit">\
                                <p class="m-cont-limittit">您已成功提交申请，请等待审核。优先购买券预计在24小时内送达您和好友的“我的账户-我的V码”中。</p>\
                                <p>可用于提前购买超级年宝，最高可购买</p>\
                                <em>10万元！</em>\
                                <p>名额有限，送完即止！</p>\
                                </div></div>'
                        alertLayer({"msgCont":msgCont,"msgWidth":501,"msgHeight":"auto"});
                    }else if(data.message.code == -9993){
                        oMaskDiv.style.display='block';
                        $(".invite-txt-tit").html('该好友尚未注册金汇理财账户，无法领取！');
                    }else{
                        var msgCont = '<div class="m-cont-msg">'+data.message.message+'</div>'
                        alertLayer({"msgCont":msgCont,"msgWidth":501,"msgHeight":"auto"});
                    }

                }
                ajax(urlCode,"post",param,succ,null);
            // }
        });
})
       
/*
 * 异步
 * @ url     连接地址
 * @ type    GET/POST...
 * @ param   传出参数
 * @ suc     处理成功返回值的函数
 * */
function ajax(url, type, param, suc, error)
{
    $.ajax({
        url: url,
        timeout:8000,
        type: type,
        data: param,
        dataType: "json",
        async: false,
        success: function(data) {
            suc && suc(data);
        },
        error: function(data) {
            if (!!error) {
                error();
            }
        }
    });
}

/**
*
*获取url参数
*
**/
function getRequest()
{
    var url = decodeURI(location.search); //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1)
    {
        var str = url.substr(1);
        strs = str.split("&");
        for(var i = 0; i < strs.length; i ++)
        {
            theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}